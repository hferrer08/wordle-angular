import { Component } from '@angular/core';

@Component({
  selector: 'app-row',
  imports: [],
  templateUrl: './row.html',
  styleUrl: './row.css',
})
export class Row {

}
